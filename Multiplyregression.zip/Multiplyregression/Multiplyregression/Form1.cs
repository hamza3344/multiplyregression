﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics;
namespace Multiplyregression
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double[][] factors = new double[8][];
            factors[0] = new double[] { 60, 22 };
            factors[1] = new double[] { 62, 25 };
            factors[2] = new double[] { 67, 24 };
            factors[3] = new double[] { 70, 20 };
            factors[4] = new double[] { 71, 15 };
            factors[5] = new double[] { 72, 14 };
            factors[6] = new double[] { 75, 14 };
            factors[7] = new double[] { 78, 11 };
            double[] predictor = new double[] { 140, 155, 159, 179, 192, 200, 212, 215 };
            var fact = Fit.MultiDim(factors, predictor, intercept: true);
            foreach(double n in fact)
            {
                MessageBox.Show(n.ToString());
            }
        }
    }
}
